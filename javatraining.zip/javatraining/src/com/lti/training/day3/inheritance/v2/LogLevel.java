package com.lti.training.day3.inheritance.v2;

public enum LogLevel {
	
	INFO,WARN,ERROR;
	
}
