package com.lti.training.day3.inheritance.v1;

public enum LogLevel {
	
	INFO,WARN,ERROR;
	
}
