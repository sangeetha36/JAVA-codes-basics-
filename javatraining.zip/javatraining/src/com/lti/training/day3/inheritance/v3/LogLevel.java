package com.lti.training.day3.inheritance.v3;

public enum LogLevel {
	
	INFO,WARN,ERROR;
	
}
