package com.lti.training.misc;

public class Student {
	
	String name;
	String college;
	String doj;

 }


