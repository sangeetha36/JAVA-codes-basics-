package com.lti.training.practice;

public class Test2 {
	public static void main(String args[]) {
		int i=10;
		System.out.println(new Integer(i).toString());
		
	}
}
