package com.lti.training.practice;

public class CountCounty {
	public static void main(String args[]) {
		int count=0,i=0;
		do {
			count +=i;
			i++;
		if(count>5) break;
		
	} while(i<=4);
		System.out.println(i);

}
}
