package com.lti.training.day4.exceptionhandling;

public class AccountException extends Exception {

	public AccountException(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}

}
